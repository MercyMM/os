/*************************************************************************
    > File Name: gloabl.c
    > Author: mercy
    > Mail:  
    > Created Time: 2015年04月17日 星期五 11时17分52秒
 ************************************************************************/

#define GLOBAL_VAR_HERE


#include "type.h"
#include "const.h"
#include "protect.h"
#include "global.h"
#include "init_idt.h"


